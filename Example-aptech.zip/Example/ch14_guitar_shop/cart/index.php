<?php include '../view/header.php'; ?>
<main>
    <h1>Shopping Cart - under construction</h1>
</main>
<?php include '../view/footer.php'; ?>
