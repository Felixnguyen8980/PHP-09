<?php  include '../util/main.php'; ?>
<?php  include '../view/header.php'; ?>
<section>
    <h1>Admin Menu</h1>
    <ul class="last_paragraph">
        <li><a href="product">Product Manager</a></li>
        <li><a href="category">Category Manager</a></li>
        <li><a href="order">Order Manager</a></li>
    </ul>
</section>
<?php include '../view/footer.php'; ?>
