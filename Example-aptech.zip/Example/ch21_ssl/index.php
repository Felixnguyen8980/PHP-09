<!DOCTYPE html>
<html>
    <head>
        <title>My Guitar Shop</title>
        <link rel="stylesheet" type="text/css" href="main.css"/>
    </head>
    <body>
        <header>
            <h1>My Guitar Shop</h1>
        </header>
        <main>
            <h1>No SSL</h1>
            <p>This page does not contain sensitive information.</p>
            <p><a href="secure.php">View sensitive information</a></p>
        </main>
    </body>
</html>
