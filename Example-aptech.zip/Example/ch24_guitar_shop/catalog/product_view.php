<?php include '../view/header.php'; ?>
<?php include '../view/sidebar.php'; ?>
<main>
    <!-- display product -->
    <?php include '../view/product.php'; ?>

</main>
<?php include '../view/footer.php'; ?>